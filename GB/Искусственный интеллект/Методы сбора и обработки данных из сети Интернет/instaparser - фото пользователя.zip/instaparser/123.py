l1 = [1, 2, 3]
l2 = l1[:]
l2.append(4)
print(l1)