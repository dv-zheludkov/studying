"""
3. Задание на закрепление знаний по модулю yaml.
 Написать скрипт, автоматизирующий сохранение данных
 в файле YAML-формата.
Для этого:

Подготовить данные для записи в виде словаря, в котором
первому ключу соответствует список, второму — целое число,
третьему — вложенный словарь, где значение каждого ключа —
это целое число с юникод-символом, отсутствующим в кодировке
ASCII(например, €);

Реализовать сохранение данных в файл формата YAML — например,
в файл file.yaml. При этом обеспечить стилизацию файла с помощью
параметра default_flow_style, а также установить возможность работы
с юникодом: allow_unicode = True;

Реализовать считывание данных из созданного файла и проверить,
совпадают ли они с исходными.
"""

import yaml

data = {'items': ['computer', 'printer', 'keyboard', 'mouse'],
        'items_quantity': 4,
        'items_price': {'computer': '200\u20ac-1000\u20ac',
         'keyboard': '5\u20ac-50\u20ac', 
         'mouse': '4\u20ac-7\u20ac', 
         'printer': '100\u20ac-300\u20ac'}}

with open('file.yaml', 'w', encoding='utf-8') as f_n:
    yaml.dump(data, f_n, allow_unicode=True, default_flow_style=False, indent=4)

with open('file.yaml', encoding='utf-8') as f_n:
    data_from_file = yaml.load(f_n, Loader=yaml.FullLoader)

if data == data_from_file:
    print('Данные записаны верно')
else:
    print('Что-то пошло не так. Исходные данные и данные, прочитанные из файла не совпадают.')






